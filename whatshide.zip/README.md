# whatshide

Hide chat preview while using Whatsapp Web.